USE `asw20`;

CREATE TABLE tamanho(
    id          int(6) PRIMARY KEY,
    nome        VARCHAR(20) NOT NULL

) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

ALTER TABLE tamanho
  MODIFY id int(6) AUTO_INCREMENT,AUTO_INCREMENT=6;


CREATE TABLE categoria(
    id          int(6) PRIMARY KEY,
    nome        VARCHAR(20) NOT NULL

) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

ALTER TABLE categoria
  MODIFY id int(6) AUTO_INCREMENT,AUTO_INCREMENT=5;


CREATE TABLE marca(
    id          int(6) PRIMARY KEY,
    nome        VARCHAR(20) NOT NULL

) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

ALTER TABLE marca
  MODIFY id int(6) AUTO_INCREMENT,AUTO_INCREMENT=5;

CREATE TABLE utilizador (
    id          int(6) PRIMARY KEY,
    nome        VARCHAR(40) NOT NULL,
    dataNasc     DATE        NOT NULL,
    genero      VARCHAR(10) NOT NULL,
    email       VARCHAR(30)   NOT NULL UNIQUE,
    telefone    int(9)  NOT NULL UNIQUE,
    morada      VARCHAR(50) NOT NULL,
    localidade  VARCHAR(10) NOT NULL,
    codigo_postal   VARCHAR(8) NOT NULL,
    senha       VARCHAR(25) NOT NULL,
    marca       int(6),
    FOREIGN KEY (marca) REFERENCES marca(id),
    CHECK (genero in ('feminino','masculino','outro'))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

ALTER TABLE utilizador
  MODIFY id int(6) AUTO_INCREMENT,AUTO_INCREMENT=16;


CREATE TABLE utilizador_categoria(
    utilizador int(6) NOT NULL,
    categoria  int(6) NOT NULL,
    FOREIGN KEY (utilizador) REFERENCES utilizador(id),
    FOREIGN KEY (categoria) REFERENCES categoria(id)
);


CREATE TABLE utilizador_tamanho(
    utilizador  int(6) NOT NULL,
    tamanho     int(6) NOT NULL,
    FOREIGN KEY (utilizador) REFERENCES utilizador(id),
    FOREIGN KEY (tamanho) REFERENCES tamanho(id)
);


CREATE TABLE produto(
    id int(6) PRIMARY KEY NOT NULL,
    titulo varchar(20) NOT NULL,
    estado varchar(30) NOT NULL,
    tipo varchar(20) NOT NULL,
    tamanho int(6) NOT NULL,
    categoria int(6) NOT NULL,
    marca int(6) NOT NULL,
    preco float NOT NULL,
    dataRegisto date DEFAULT NULL,
    descricao varchar(150) NOT NULL,
    vendedor int(6) NOT NULL,
    imagem varchar(256) DEFAULT NULL
    FOREIGN KEY (vendedor) REFERENCES utilizador(id),
    FOREIGN KEY (tamanho) REFERENCES tamanho(id),
    FOREIGN KEY (categoria) REFERENCES categoria(id),
    FOREIGN KEY (marca) REFERENCES marca(id),
    CHECK(estado in 
    ('Novo com etiqueta', 'Novo sem etiqueta','Muito bom', 'Bom', 'Satisfatório')),
    FOREIGN KEY (imagem) REFERENCES images(id)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=latin1;

ALTER TABLE produto
  MODIFY id int(6) AUTO_INCREMENT,AUTO_INCREMENT=0;


CREATE TABLE favoritos(
    utilizador         int(6)  NOT NULL,
    produto            int(6) NOT NULL,
    FOREIGN KEY (utilizador) REFERENCES utilizador (id),
    FOREIGN KEY (produto) REFERENCES produto (id)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

ALTER TABLE `favoritos`
  MODIFY `id` int(6) AUTO_INCREMENT,AUTO_INCREMENT=1;

CREATE TABLE compra(
    id          int(6) PRIMARY KEY,
    vendedor    int(6) NOT NULL,
    comprador   int(6) NOT NULL,
    produto     int(6) NOT NULL,
    dataVenda   DATE NOT NULL,
    FOREIGN KEY (vendedor) REFERENCES utilizador(id),
    FOREIGN KEY (comprador) REFERENCES utilizador(id),
    FOREIGN KEY (produto) REFERENCES produto(id)
)ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=latin1;


ALTER TABLE compra
  MODIFY `id` int(6) AUTO_INCREMENT,AUTO_INCREMENT=1;


CREATE TABLE  images (
  id int(11) PRIMARY KEY NOT NULL,
  filename varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

ALTER TABLE images
  MODIFY id int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;

INSERT INTO `utilizador` (`id`, `nome`, `dataNasc`, `genero`, `email`, `telefone`, `morada`, `localidade`, `codigo_postal`, `senha`, `marca`) VALUES
(2, 'Raquel', '0009-09-08', 'feminino', 'marno3@gmail.com', 910214061, 'Rua das corujas n10 Montoito Atalaia-LourinhÃ£', 'LourinhÃ£', '2530-057', '$2y$10$0Jshwx/R/mkBS0BysD', 2),
(3, 'Raquel', '0009-09-08', 'feminino', 'mao3@gmail.com', 914514061, 'Rua das corujas n10 Montoito Atalaia-LourinhÃ£', 'LourinhÃ£', '2530-057', '$2y$10$Lk9/dObsW0HpXIrd5Z', NULL),
(4, 'Sara', '0009-09-08', 'feminino', 'ma3@gmail.com', 914514060, 'Rua das corujas n10 Montoito Atalaia-LourinhÃ£', 'LourinhÃ£', '2530-057', '$2y$10$zfyx8X/ZZuu/xfY.rf', 1),
(5, 'Sarap', '0009-09-08', 'feminino', 'ma@gmail.com', 914514076, 'Rua das corujas n10 Montoito Atalaia-LourinhÃ£', 'LourinhÃ£', '2530-057', '$2y$10$SnOe0uw3IEca7MLco7', NULL),
(6, 'Rodrigo', '0009-09-08', 'feminino', 'mcfghjkma@gmail.com', 914514072, 'Rua das corujas n10 Montoito Atalaia-LourinhÃ£', 'LourinhÃ£', '2530-057', '$2y$10$FqXQSaNI/a/4nql3mK', 0),
(7, 'Rodrigoi', '0009-09-08', 'feminino', 'mcfghnjkma@gmail.com', 914514073, 'Rua das corujas n10 Montoito Atalaia-LourinhÃ£', 'LourinhÃ£', '2530-057', '$2y$10$pzJEE/vUKkbpnZ6Zqs', 1),
(8, 'joao', '0009-09-08', 'feminino', 'mcfghnja@gmail.com', 914514009, 'Rua das corujas n10 Montoito Atalaia-LourinhÃ£', 'LourinhÃ£', '2530-057', '$2y$10$XJEJRtyafTY7mt4dmv', 2),
(9, 'joaona', '0009-09-08', 'feminino', 'mcfnja@gmail.com', 914514000, 'Rua das corujas n10 Montoito Atalaia-LourinhÃ£', 'LourinhÃ£', '2530-057', '$2y$10$Sjfk0lGs4qxIIcAj4i', NULL),
(10, 'J1oaona', '0009-09-08', 'feminino', 'mcfnmnja@gmail.com', 914514003, 'Rua das corujas n10 Montoito Atalaia-LourinhÃ£', 'LourinhÃ£', '2530-057', '$2y$10$Z0BSle2nw1LdJVAqVa', NULL),
(12, 'judas', '0009-09-08', 'feminino', 'mc1fnja@gmail.com', 914514005, 'Rua das corujas n10 Montoito Atalaia-LourinhÃ£', 'LourinhÃ£', '2530-057', '$2y$10$52IZSjjjlfsVSjwX15', 2),
(13, 'Mariana Foz', '7890-06-05', 'outro', 'marianafoz2703@gmail.com', 910114064, 'Rua das corujas n10 Montoito Atalaia-LourinhÃ£', 'LourinhÃ£', '2530-057', '$2y$10$0AXG1ROsh1zVBVmGqZ', NULL),
(14, 'Raquel', '2003-02-01', 'feminino', 'raq@hj.cp', 912069170, 'Rua', 'Atalaia', '1000-001', '$2y$10$2S0rVlh/npIdtc.L8K', NULL),
(15, 'Marta', '2003-02-01', 'feminino', 'radq@hj.cp', 912069171, 'Rua', 'Atalaia', '1000-001', '$2y$10$DV7p4Ywc4JQZz1h7vJ', NULL);


INSERT INTO `categoria` (`id`, `nome`) VALUES
(1, 'mulher'),
(2, 'homem'),
(3, 'criança'),
(4, 'outro');


INSERT INTO `marca` (`id`, `nome`) VALUES
(0, 'berska'),
(1, 'tiffosi'),
(2, 'pullBear'),
(3, 'levis');


INSERT INTO `tamanho` (`id`, `nome`) VALUES
(1, 'XS'),
(2, 'S'),
(3, 'M'),
(4, 'L'),
(5, 'XL');



CREATE TABLE chat(
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    utilizador1 INT(6) NOT NULL,
    utilizador2 INT(6) NOT NULL,
    dataHora TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    produto INT(6) NOT NULL,
    mensagem VARCHAR(500) NOT NULL,
    FOREIGN KEY (produto) REFERENCES produto(id),
    FOREIGN KEY (utilizador1) REFERENCES utilizador(id),
    FOREIGN KEY (utilizador2) REFERENCES utilizador(id)

);

